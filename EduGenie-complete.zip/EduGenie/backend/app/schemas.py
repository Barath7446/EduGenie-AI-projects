from pydantic import BaseModel, Field, field_validator

class TextRequest(BaseModel):
    text: str = Field(min_length=1, max_length=20000)
    @field_validator("text")
    @classmethod
    def clean(cls,v):
        v=v.strip()
        if not v: raise ValueError("Text cannot be empty")
        return v

class TopicRequest(BaseModel):
    topic: str = Field(min_length=1, max_length=500)
    @field_validator("topic")
    @classmethod
    def clean(cls,v):
        v=v.strip()
        if not v: raise ValueError("Topic cannot be empty")
        return v

class QuestionRequest(BaseModel):
    question: str = Field(min_length=1, max_length=5000)
    @field_validator("question")
    @classmethod
    def clean(cls,v):
        v=v.strip()
        if not v: raise ValueError("Question cannot be empty")
        return v

class QuizRequest(BaseModel):
    text: str = Field(min_length=1, max_length=20000)
    count: int = Field(default=5, ge=1, le=10)
    @field_validator("text")
    @classmethod
    def clean(cls,v):
        v=v.strip()
        if not v: raise ValueError("Text cannot be empty")
        return v

class QuizQuestion(BaseModel):
    question: str
    options: list[str] = Field(min_length=4, max_length=4)
    answer: str
    explanation: str = ""

class QuizResponse(BaseModel):
    questions: list[QuizQuestion]
    source: str

class TextResponse(BaseModel):
    result: str
    source: str

class HealthResponse(BaseModel):
    status: str
    gemini_configured: bool
    model: str
