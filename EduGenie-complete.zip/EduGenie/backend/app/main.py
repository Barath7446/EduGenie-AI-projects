from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .config import get_settings
from .gemini import service
from .schemas import HealthResponse,QuestionRequest,QuizRequest,QuizResponse,QuizQuestion,TextRequest,TextResponse,TopicRequest

settings=get_settings()
app=FastAPI(title="EduGenie API",description="Google Gemini powered learning assistant API",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=settings.origins,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

def ai_or_fallback(prompt,fallback):
    if not service.configured: return fallback,"demo"
    try: return service.generate(prompt),"gemini"
    except Exception as exc: raise HTTPException(status_code=502,detail=f"Gemini request failed: {exc}") from exc

@app.get("/",include_in_schema=False)
def root(): return {"message":"EduGenie API is running","docs":"/docs"}

@app.get("/health",response_model=HealthResponse)
def health(): return HealthResponse(status="ok",gemini_configured=service.configured,model=settings.gemini_model)

@app.post("/api/explain",response_model=TextResponse)
@app.post("/explain",response_model=TextResponse,include_in_schema=False)
def explain(request:TopicRequest):
    result,source=ai_or_fallback(f"Explain the topic '{request.topic}' to a student in simple language. Use a short definition, key ideas, and one example.",
        f"{request.topic} is a topic that can be explored step by step. Add a Gemini API key to generate a full personalized explanation.")
    return TextResponse(result=result,source=source)

@app.post("/api/qa",response_model=TextResponse)
@app.post("/qa",response_model=TextResponse,include_in_schema=False)
def qa(request:QuestionRequest):
    result,source=ai_or_fallback(f"You are EduGenie, a patient AI tutor. Answer accurately and clearly, showing reasoning where useful: {request.question}",
        "Demo mode is active. Configure GEMINI_API_KEY in backend/.env to receive a Gemini answer.")
    return TextResponse(result=result,source=source)

@app.post("/api/summarize",response_model=TextResponse)
@app.post("/summarize",response_model=TextResponse,include_in_schema=False)
def summarize(request:TextRequest):
    result,source=ai_or_fallback(f"Summarize the following text in simple language. Preserve important facts and do not add unsupported claims.\n\n{request.text}",
        f"Demo summary: {request.text[:400]}{'...' if len(request.text)>400 else ''}")
    return TextResponse(result=result,source=source)

@app.post("/api/learn/recommendations",response_model=TextResponse)
@app.post("/learn/recommendations",response_model=TextResponse,include_in_schema=False)
def recommendations(request:TopicRequest):
    prompt=f"""You are an AI tutor. The student wants to learn about: {request.topic}.
Suggest a structured adaptive learning path with beginner, intermediate, and advanced levels where appropriate.
For each level include key topics, suggested order, practice ideas, and reputable resource types."""
    result,source=ai_or_fallback(prompt,
        f"Learning path for {request.topic}: start with definitions and fundamentals, practice basic examples, then progress to intermediate applications and advanced projects. Configure GEMINI_API_KEY for a personalized path.")
    return TextResponse(result=result,source=source)

@app.post("/api/quiz",response_model=QuizResponse)
@app.post("/quiz",response_model=QuizResponse,include_in_schema=False)
def quiz(request:QuizRequest):
    if not service.configured:
        questions=[QuizQuestion(question="What is the main purpose of EduGenie?",options=["Learning support","Video editing","Image compression","File recovery"],answer="Learning support",explanation="EduGenie is documented as a learning assistant.")]
        while len(questions)<min(request.count,5):
            questions.append(QuizQuestion(question=f"Demo question {len(questions)+1}: What enables Gemini-generated quizzes?",options=["Configure GEMINI_API_KEY","Delete the frontend","Disable FastAPI","Remove the quiz page"],answer="Configure GEMINI_API_KEY",explanation="The Gemini API key enables live AI generation."))
        return QuizResponse(questions=questions[:request.count],source="demo")
    try: return QuizResponse(questions=[QuizQuestion(**x) for x in service.generate_quiz(request.text,request.count)],source="gemini")
    except Exception as exc: raise HTTPException(status_code=502,detail=f"Gemini quiz generation failed: {exc}") from exc
