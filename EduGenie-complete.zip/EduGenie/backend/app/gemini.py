import json
from google import genai
from google.genai import types
from .config import get_settings

class GeminiService:
    def __init__(self):
        self.settings=get_settings()
        self._client=None
    @property
    def configured(self): return bool(self.settings.gemini_api_key.strip())
    def _client_or_raise(self):
        if not self.configured: raise RuntimeError("GEMINI_API_KEY is not configured")
        if self._client is None: self._client=genai.Client(api_key=self.settings.gemini_api_key)
        return self._client
    def generate(self,prompt,temperature=0.4):
        response=self._client_or_raise().models.generate_content(
            model=self.settings.gemini_model, contents=prompt,
            config=types.GenerateContentConfig(temperature=temperature,max_output_tokens=1800))
        text=(response.text or "").strip()
        if not text: raise RuntimeError("Gemini returned an empty response")
        return text
    def generate_quiz(self,passage,count):
        schema={"type":"array","items":{"type":"object","properties":{
            "question":{"type":"string"},"options":{"type":"array","items":{"type":"string"}},
            "answer":{"type":"string"},"explanation":{"type":"string"}},
            "required":["question","options","answer","explanation"]}}
        prompt=f"""You are EduGenie, an educational quiz generator.
Create exactly {count} multiple-choice questions from the passage below.
Each question must have exactly four distinct options and exactly one correct answer.
Return ONLY valid JSON. The answer must exactly equal one option.
PASSAGE:
{passage}"""
        response=self._client_or_raise().models.generate_content(
            model=self.settings.gemini_model, contents=prompt,
            config=types.GenerateContentConfig(temperature=0.3,max_output_tokens=3000,
                response_mime_type="application/json",response_schema=schema))
        data=json.loads((response.text or "").strip())
        valid=[]
        for item in data[:count]:
            opts=item.get("options",[]); ans=item.get("answer","")
            if isinstance(opts,list) and len(opts)==4 and ans in opts:
                valid.append({"question":str(item.get("question","")).strip(),
                    "options":[str(x).strip() for x in opts],"answer":str(ans).strip(),
                    "explanation":str(item.get("explanation","")).strip()})
        if len(valid)!=count: raise ValueError("Gemini returned an invalid quiz structure")
        return valid
service=GeminiService()
