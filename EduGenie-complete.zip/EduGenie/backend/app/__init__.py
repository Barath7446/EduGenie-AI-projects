"""EduGenie backend package."""
