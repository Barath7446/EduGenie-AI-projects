# EduGenie — Google Gemini Powered Learning Assistant

Complete full-stack implementation of the supplied EduGenie specification.

## Features
- AI Q&A
- Topic explanations
- Personalized learning recommendations
- Paragraph summarization
- Multiple-choice quiz generation
- Browser-side quiz answer checking
- FastAPI backend + React/Vite frontend
- Gemini API integration with structured JSON quiz output
- Demo fallback when no Gemini key is configured

## Structure
```text
EduGenie/
├── backend/app/{__init__.py,config.py,gemini.py,main.py,schemas.py}
├── backend/{requirements.txt,.env.example}
├── frontend/src/{main.jsx,styles.css}
├── frontend/{package.json,index.html,.env.example}
├── tests/test_api.py
└── README.md
```

## Requirements
Python 3.11+, Node.js 20+, VS Code, and a Gemini API key for live AI responses.

## Windows / VS Code setup

### 1. Open the project
Open the `EduGenie` folder in VS Code.

### 2. Backend virtual environment
In Terminal 1:
```powershell
cd backend
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```
Edit `backend/.env` and set `GEMINI_API_KEY` to your Gemini API key.

If PowerShell blocks activation:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### 3. Start FastAPI
Still inside `backend`:
```powershell
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
Open:
- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/health

**Important:** If you see `No module named 'backend'`, do not run `backend.app.main:app` from the `backend` directory. Use exactly `app.main:app` as shown above.

### 4. Start React frontend
Open Terminal 2:
```powershell
cd frontend
npm install
Copy-Item .env.example .env
npm run dev
```
Open:
**http://127.0.0.1:5173**

The frontend calls `http://127.0.0.1:8000` by default.

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | API and Gemini status |
| POST | `/api/qa` | Answer a student question |
| POST | `/api/explain` | Explain a topic |
| POST | `/api/summarize` | Summarize text |
| POST | `/api/learn/recommendations` | Generate a learning path |
| POST | `/api/quiz` | Generate MCQs |

Compatibility aliases are also available at `/qa`, `/explain`, `/summarize`, `/learn/recommendations`, and `/quiz`.

## API examples
```json
POST /api/qa
{"question":"Why is the sky blue?"}
```
```json
POST /api/explain
{"topic":"Quantum computing"}
```
```json
POST /api/summarize
{"text":"Your paragraph goes here..."}
```
```json
POST /api/learn/recommendations
{"topic":"SQL"}
```
```json
POST /api/quiz
{"text":"The Pythagorean theorem states that a²+b²=c² for a right triangle.","count":5}
```

## Testing
From the project root, after activating the backend environment:
```powershell
cd backend
.\.venv\Scripts\Activate.ps1
cd ..
pip install pytest httpx
pytest -q
```

## Gemini configuration
The backend uses the current `google-genai` Python SDK and reads `GEMINI_API_KEY` and `GEMINI_MODEL` from `.env`. If no key is configured, the UI and API remain runnable in demo mode; live AI generation requires the key.
