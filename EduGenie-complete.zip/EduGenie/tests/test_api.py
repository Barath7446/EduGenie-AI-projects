import sys
from pathlib import Path
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"backend"))
from app.main import app
client=TestClient(app)
def test_health():
    r=client.get("/health"); assert r.status_code==200; assert r.json()["status"]=="ok"
def test_explain_demo():
    r=client.post("/api/explain",json={"topic":"Photosynthesis"}); assert r.status_code==200 and "result" in r.json()
def test_quiz_demo():
    r=client.post("/api/quiz",json={"text":"A right triangle follows a²+b²=c².","count":3}); assert r.status_code==200 and len(r.json()["questions"])==3
